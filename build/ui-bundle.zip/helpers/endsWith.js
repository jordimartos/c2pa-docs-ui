'use strict'

module.exports = (subject, string) => subject.endsWith(string)
